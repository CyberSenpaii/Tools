//go:build android
// +build android

package main

func ServiceManagerStartNotify() error {
	return nil
}

func ServiceManagerReadyNotify() error {
	return nil
}
