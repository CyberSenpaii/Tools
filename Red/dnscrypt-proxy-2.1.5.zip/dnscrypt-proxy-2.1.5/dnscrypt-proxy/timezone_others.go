//go:build !android
// +build !android

package main

func TimezoneSetup() error {
	return nil
}
