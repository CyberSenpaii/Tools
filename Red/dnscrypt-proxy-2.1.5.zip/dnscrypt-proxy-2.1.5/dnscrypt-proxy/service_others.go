//go:build !linux && !windows
// +build !linux,!windows

package main

func ServiceManagerStartNotify() error {
	return nil
}

func ServiceManagerReadyNotify() error {
	return nil
}
