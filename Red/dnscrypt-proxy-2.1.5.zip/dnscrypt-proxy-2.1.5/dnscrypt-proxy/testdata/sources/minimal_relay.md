# Minimal example of a relay source list

## Blank address

sdns://gQA

