---
name: "🙋🏽 Planned changes"
about: List of planned changes
title: ''
labels: ''
assignees: ''

---

The starting point should be a discussion.

https://github.com/DNSCrypt/dnscrypt-proxy/discussions/

Suggestions may be raised as an "Ideas" discussion.

We can then determine if the discussion needs to be escalated into a "planned change" or not.

This will help us ensure that the issue tracker properly reflects ongoing or needed work on the project.

---

- [ ] Initially raised as discussion #...
