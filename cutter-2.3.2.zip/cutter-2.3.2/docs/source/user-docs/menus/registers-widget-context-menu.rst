Registers Widget Context Menu 
==============================

Copy Register Value
----------------------------------------
**Description:** Copy the value of the selected register. *This option is only available on Debug or Emulation modes*.   

**Steps:** Right-click a register in the widget and choose ``Copy register value``.  

Copy Register Reference
----------------------------------------
**Description:** Copy the value of the data referenced from the selected register. *This option is only available on Debug or Emulation modes*.  

**Steps:** Right-click a register in the widget and choose ``Copy register reference``.