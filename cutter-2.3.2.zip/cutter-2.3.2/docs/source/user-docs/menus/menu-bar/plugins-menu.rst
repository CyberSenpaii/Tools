Plugins Menu
==============================

Plugins Sub-Menu
----------------------------------------
**Description:** This menu will contain the windows and views created by the loaded plugins. By default, this menu is empty unless plugins added their actions and items to the menu.    

**Steps:** Windows -> Plugins
