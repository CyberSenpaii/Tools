import sys

from floss.main import main

sys.exit(main())
