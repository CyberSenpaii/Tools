# Copyright (C) 2017 Mandiant, Inc. All Rights Reserved.
# caution: this file gets overwritten when building using PyInstaller, don't add required data in here without handling
__version__ = "2.3.0"
