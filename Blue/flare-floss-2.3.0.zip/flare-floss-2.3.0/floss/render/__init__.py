from enum import Enum


class Verbosity(int, Enum):
    DEFAULT = 0
    VERBOSE = 1
